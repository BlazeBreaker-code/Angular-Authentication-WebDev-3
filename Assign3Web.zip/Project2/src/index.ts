import express from 'express'; 
import http from 'http';

import swaggerUI from 'swagger-ui-express'; 
import cors from 'cors';
import * as fs from "fs";
import * as path from 'path';
import bodyParser from 'body-parser'; 


import { postRouter } from './routes/posts';
import { userRouter } from './routes/users';
import { categoriesRouter } from './routes/categories';
//import { categoriesRouter } from 'src/routes/categories';
//import { usersArray } from 'src/models/user';
// import { postscategoriesRouter } from 'src/routes/postcategories';


let app = express(); 

//app.use(cors({credentials: true, origin: true}));
//app.options('*', cors({credentials: true, origin: true}));
//let swagger_doc = fs.readFileSync(path.join(process.cwd(), 'src', 'openapi.json'));
//let swagger_obj = JSON.parse(swagger_doc.toString()); 
//app.use(bodyParser.json()); 
app.use(bodyParser.urlencoded({ extended: true})); //YOOO SHOUTOUT TO ARFAN FOR FIXING THIS BODYPARSER CODE MANNNNNNGGNGN

app.use('/Users', userRouter);
app.use('/Posts', postRouter);
app.use('/Categories', categoriesRouter);
//app.use('/PostCategory', postscategoriesRouter);

//app.use('/', swaggerUI.serve, swaggerUI.setup(swagger_obj));

let server = http.createServer(app);
server.listen(3000);

//app.listen(3000);