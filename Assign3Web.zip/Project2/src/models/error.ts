export class ErrorMessage {
    status:number;
    message:String;


    constructor(status: number,message:String) {
        this.status = status; 
        this.message = message; 
    }
}


