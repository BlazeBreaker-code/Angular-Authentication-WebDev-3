export class Categories  {
    categoryId: number; 
    categoryName: string; 
    categoryDescription : string;

    constructor(categoryId: number, categoryName: string, categoryDescription: string) {
        this.categoryName = categoryName; 
        this.categoryDescription = categoryDescription; 
        this.categoryId = categoryId;     
    }
}

const categoriesArray: Categories[] = [];
const CAT_ID_HOLDER = {NextCatID:1}
export {categoriesArray, CAT_ID_HOLDER}