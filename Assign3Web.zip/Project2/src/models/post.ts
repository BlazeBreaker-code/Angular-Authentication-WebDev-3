export class Post {
    postId:number;
    createdDate : Date; 
    title : string; 
    content : string; 
    userId: string; 
    headerImage: string; 
    lastUpdated: Date;


    constructor(postId:number, title: string, content: string, userId: string, headerImage: string) {
        this.postId = postId; 
        this.userId = userId; 
        this.createdDate = new Date();
        this.title = title; 
        this.content = content; 
        this.headerImage = headerImage; 
        this.lastUpdated = new Date(); 
    }
}

const postsArray : Post[] = [];

export {postsArray};