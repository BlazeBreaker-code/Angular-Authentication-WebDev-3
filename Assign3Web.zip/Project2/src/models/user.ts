import bcrypt from 'bcrypt'; 
import * as EmailValidator from 'email-validator';

export class User {
    userId = '';
    firstName = '';
    lastName = '';
    emailAddress = '';
    password = '';
  
  
  constructor(userId:string, firstName: string, lastName: string, emailAddress: string, password: string ) {
      this.userId = userId; 
      this.firstName = firstName; 
      this.lastName = lastName;
      this.emailAddress = emailAddress; 
      this.password = '';
  }

  static ToUser(obj:any): User|boolean{
    return obj.hasOwnProperty('userId') && obj.hasOwnProperty('firstName') && obj.hasOwnProperty('lastName') && obj.hasOwnProperty('emailAddress') ? new User(obj.userId, obj.firstName, obj.lastName, obj.emailAddress, ''): false;
}

  static ValidateEmail (emailAddress : string): boolean {
      return EmailValidator.validate(emailAddress);
  }

  toJSON() {
      let ReturnUsr =<any> User.ToUser(this); 
      delete ReturnUsr.password; 
      return ReturnUsr; 
  }

  setPassword(password: string) {
      bcrypt.hash(password,10, (err,hash) => {
          this.password = hash;
      });
  }

  validatePassword(password : string) {
      return bcrypt.compare(password, this.password);
  }
} 
  
  const usersArray: User[] = [];
  let GlobalSalt = '';
  export {usersArray, GlobalSalt}