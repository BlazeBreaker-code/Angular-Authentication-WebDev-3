export class Comment {
    commentId: number; 
    comment: string; 
    userId: string;
    postId: number;
    commentDate: Date;
    
    
    constructor(commentId: number, comment:string, userId: string, postId: number, commentDate: Date) {
        this.commentId=0;
        this.comment = comment;
        this.userId = userId;
        this.postId=0;
        this.commentDate = new Date();

    }
}


const commentsArray: Comment[] = [];

export {commentsArray};