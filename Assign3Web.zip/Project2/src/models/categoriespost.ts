export class CategoriesPost {
    categoryId: number; 
    postId: number; 
    constructor(categoryId : number, postId : number) {
        this.categoryId=categoryId;
        this.postId=0;
    }
}


const catPostArray: CategoriesPost[] = [];

export {catPostArray};