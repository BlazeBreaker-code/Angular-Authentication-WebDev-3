import {IncomingHttpHeaders} from 'http';
import {User, usersArray} from '../models/user';
import jwt from 'jsonwebtoken';

export class JWTAuth
{
    static SecretSalt = 'myhktg';
    static VerifyToken(headers: IncomingHttpHeaders): User|String
    {
        if(headers.authorization && headers.authorization.split(' ')[0]==='Bearer')
        {
            try
            {
                let user = jwt.verify(headers.authorization.split(' ')[1], JWTAuth.SecretSalt) as any;
                if(user.UserData)
                {
                    let currentUser = User.ToUser(user.UserData)
                    if(currentUser instanceof User)
                    {
                        if(usersArray.find(u => u.userId ===(<User>currentUser).userId)){
                            return currentUser;
                        } else{
                            throw `Invalid user ${(<User>currentUser).userId}`;
                        }
                        
                    }
                    else{
                        throw 'Malformed User Data in JWT'
                    }
                    
                }
                else{
                    throw 'Malformed User Data in JWT'
                }
                
                    }
                    catch(ex)
                    {
                        return ex.toString();
                    }
                
                }
                else return 'Invalid Authorization Header';
}

static GenerateWebToken(user:User)
{
    console.log(user);
    let token = jwt.sign({UserData:user},JWTAuth.SecretSalt,{expiresIn:900, subject:user.userId});
    console.log(token);
    return token;
}
}