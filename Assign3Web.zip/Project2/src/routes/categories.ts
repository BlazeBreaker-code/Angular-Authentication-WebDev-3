import express from 'express'; 

import { User, usersArray } from '../models/user'; 
import { Post, postsArray } from '../models/post';
import { Categories, categoriesArray, CAT_ID_HOLDER } from '../models/categories';
import { ErrorMessage } from '../models/error'; 
import { JWTAuth } from "../utils/jwtauth";
import { emitKeypressEvents } from 'readline';

const categoriesRouter = express.Router();

categoriesRouter.get("/:categoryId", (req, res, next) => {
    let cat=categoriesArray.filter(p=>p.categoryId===+req.params.categoryId); 
    if(cat.length>0) 
      res.status(200).send(cat[0]); 
    else
      res.status(404).send(new ErrorMessage(404, `Category: ${req.params.categoryId} not found`));  
  }); 

  categoriesRouter.patch("/:categoryId", (req, res,next)=> {
    let currentUser = JWTAuth.VerifyToken(req.headers); 
    if(currentUser instanceof User)
    {
      let cat=categoriesArray.filter(p=>p.categoryId===+req.params.categoryId); 
      if(cat.length>0)
      {
        if(cat[0].categoryName === currentUser.userId) 
        {
            if(req.body.categoryName) {
              cat[0].categoryName = req.body.categoryName; 
            }
            if(req.body.categoryDescription) {
              cat[0].categoryDescription=req.body.categoryDescription; 
            }
            if(req.body.categoryId) {
              cat[0].categoryId=req.body.headerImage; 
            }
  
            res.status(200).send(cat[0]); 
        }
  
        else 
        {
          res.status(401).send(new ErrorMessage(401, `Access Denied: Current User:  ${currentUser.userId} is nmot the owner of this post`)); 
        }
      }
      else
        res.status(404).send(new ErrorMessage(404, `Post: ${req.params.postId} not found`));  
    }
    else 
      res.status(401).send(new ErrorMessage(401, currentUser));  
  });
  


  categoriesRouter.delete("/:categoryId", (req, res, next) => {
    let currentUser = JWTAuth.VerifyToken(req.headers); 
    if(currentUser instanceof User)
    {
      let cat=categoriesArray.filter(p=>p.categoryId ===+req.params.categoryId); 
      if(cat.length>0)
      {
        let updated = false; 
        if(cat[0].categoryName === currentUser.userId) 
        {
            categoriesArray.splice(categoriesArray.findIndex(u=>u.categoryId ===+req.params.categoryId), 1);
          res.status(204).send('');
        }
      }
      else
        res.status(404).send(new ErrorMessage(404, `Post: ${req.params.categoryId} not found`));  
    }
    res.status(401).send(new ErrorMessage(401, ''));  
  });
  

  categoriesRouter.get("/", (req, res, next) =>{
    res.status(200).send(categoriesArray);  
  });
  
  categoriesRouter.post("/", (req,res, next)=>{
    let currentUser = JWTAuth.VerifyToken(req.headers); 
    if(currentUser instanceof User) 
    {
      if(categoriesArray.filter(f=>f.categoryName === req.body.categoryName).length>0)
            res.status(409).send(new ErrorMessage(409, 'Duplicate Category name'));
      else if (req.body.categoryName === '' || req.body.categoryDescription==='') {
            res.status(406).send(new ErrorMessage(406,`Category name Category Description are Required`)); 
      }
      else
      {
        let cat = new Categories(CAT_ID_HOLDER.NextCatID++, req.body.categoryName, req.body.categoryDescription);
        categoriesArray.push(cat);
        res.status(201).send(cat); 
      }
    }
    else
      res.status(401).send(new ErrorMessage(401, currentUser));  
  });
  
export { categoriesRouter };