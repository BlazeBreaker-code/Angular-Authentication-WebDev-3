import express from 'express'; 

import { User, usersArray } from '../models/user'; 
import { Post, postsArray } from '../models/post';
import { ErrorMessage } from '../models/error';
import { JWTAuth } from '../utils/jwtauth'; 

const postRouter = express.Router(); 

postRouter.get("/:postId", (req, res, next) => {
  let post=postsArray.filter(p=>p.postId===+req.params.postId); 
  if(post.length>0) 
    res.status(200).send(post[0]); 
  else
    res.status(404).send(new ErrorMessage(404, `Post: ${req.params.postId} not found`));  
}); 

postRouter.patch("/:postId", (req, res,next)=> {
  let currentUser = JWTAuth.VerifyToken(req.headers); 
  if(currentUser instanceof User)
  {
    let post=postsArray.filter(p=>p.postId===+req.params.postId); 
    if(post.length>0)
    {
      let updated=false; 
      if(post[0].userId === currentUser.userId) 
      {
          if(req.body.title) {
            post[0].title = req.body.title; 
            updated = true;
          }
          if(req.body.content) {
            post[0].content=req.body.content; 
            updated  = true; 
          }
          if(req.body.headerImage) {
            post[0].headerImage=req.body.headerImage; 
            updated  = true; 
          }
          if(updated) {
            post[0].lastUpdated = new Date(); 
          }

          res.status(200).send(post[0]); 
      }

      else 
      {
        res.status(401).send(new ErrorMessage(401, `Access Denied: Current User:  ${currentUser.userId} is not the owner of this post`)); 
      }
    }
    else
      res.status(404).send(new ErrorMessage(404, `Post: ${req.params.postId} not found`));  
  }
  else 
    res.status(401).send(new ErrorMessage(401, currentUser));  
});

postRouter.delete("/:postId", (req, res, next) => {
  let currentUser = JWTAuth.VerifyToken(req.headers); 
  
  if(currentUser instanceof User)
  {
    let post=postsArray.filter(p=>p.postId ===+req.params.postId); 
    if(post.length>0)
    {
      let updated = false; 
      if(post[0].userId === currentUser.userId) 
      {
        postsArray.splice(postsArray.findIndex(u=>u.postId ===+req.params.postId), 1);
        res.status(204).send('');
      }
    }
    else
      res.status(404).send(new ErrorMessage(404, `Post: ${req.params.postId} not found`));  
  }

  res.status(401).send(new ErrorMessage(401, ''));  
});

postRouter.get("/", (req, res, next) =>{
  res.status(200).send(postsArray);  
});

postRouter.post("/", (req,res, next)=>{
  let currentUser = JWTAuth.VerifyToken(req.headers); 
  if(currentUser instanceof User) 
  {
    if(!req.body.title || !req.body.content)
    {
      res.status(401).send(new ErrorMessage(406,`Invalid Post Object, Title and Content are Required`)); 
    }
    else
    {
      var newPost = new Post(postsArray.length ==0?1:Math.max.apply(Math, postsArray.map((p)=>{ return p.postId; }))+1, req.body.title, req.body.userId, req.body.content, req.body.headerImage);
      postsArray[postsArray.length] = newPost;

      res.status(201).send(newPost); 
    }
  }
  else
    res.status(401).send(new ErrorMessage(401, ''));  
});




export {postRouter};