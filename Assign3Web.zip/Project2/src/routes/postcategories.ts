import express from 'express'; 

import { User, usersArray } from '../models/user'; 
import { Post, postsArray } from '../models/post';
import { Categories, categoriesArray, CAT_ID_HOLDER } from '../models/categories';
import {CategoriesPost, catPostArray} from '../models/categoriespost';
import { ErrorMessage } from '../models/error'; 
import { JWTAuth } from "../utils/jwtauth";
import { emitKeypressEvents } from 'readline';

const postcategoriesRouter = express.Router();

postcategoriesRouter.get("/:categoryId", (req, res, next) => {
    let cat=catPostArray.filter(p=>p.categoryId===+req.params.categoryId); 
    if(cat.length>0) 
      res.status(200).send(cat[0]); 
    else
      res.status(404).send(new ErrorMessage(404, `Category: ${req.params.categoryId} not found`));  
  }); 
  
  postcategoriesRouter.delete("/:postId/:categoryId", (req, res, next) => {
    let categorID = +req.params.categoryId; 
    let postId = +req.params.postId; 

    let currentUser = JWTAuth.VerifyToken(req.headers); 
    if(currentUser instanceof User) 
    {
        let foundCategory = categoriesArray.find(c=> c.categoryId === categorID); 
        let foundPost = postsArray.find(p=>p.postId === postId);
        if (foundCategory && foundPost)
        {
            catPostArray.splice((new CategoriesPost(postId, categorID), 1));
            res.status(201).send(catPostArray); 
        }
      else
      {
        res.status(404).send(new ErrorMessage(404, `Category: ${req.params.categoryId} not found! or Post: ${req.params.postId} not Found!`));
      }
    }
    else
      res.status(401).send(new ErrorMessage(401, currentUser));  
  });
  
  postcategoriesRouter.get("/:postId", (req, res, next) =>{
    res.status(200).send(catPostArray);  
  });
  
  postcategoriesRouter.post("/:postId/:categoryId", (req,res, next)=>{
    let categorID = +req.params.categoryId; 
    let postId = +req.params.postId; 

    let currentUser = JWTAuth.VerifyToken(req.headers); 
    if(currentUser instanceof User) 
    {
        let foundCategory = categoriesArray.find(c=> c.categoryId === categorID); 
        let foundPost = postsArray.find(p=>p.postId === postId);
        if (foundCategory && foundPost)
        {
            catPostArray.push(new CategoriesPost(postId, categorID));
            res.status(201).send(catPostArray); 
        }
      else
      {
        res.status(404).send(new ErrorMessage(404, `Category: ${req.params.categoryId} not found! or Post: ${req.params.postId} not Found!`));
      }
    }
    else
      res.status(401).send(new ErrorMessage(401, currentUser));  
  });


export { postcategoriesRouter };