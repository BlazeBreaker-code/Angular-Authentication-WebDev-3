import express from 'express'; 
import {IncomingHttpHeaders} from 'http';
import { usersArray, User } from '../models/user';
import {ErrorMessage} from '../models/error'; 
import { JWTAuth } from "../utils/jwtauth"
import bcrypt from 'bcrypt';


const userRouter = express.Router();

let salt ='';

userRouter.get("/:userId/:password", (req,res,next)=> {
    let foundUser = usersArray.filter(u=>u.userId === req.params.userId); 
    if(foundUser.length>0) 
    {
        foundUser[0].validatePassword(req.params.password).then((validPwd) => 
        {
            if(validPwd) {
                let token = JWTAuth.GenerateWebToken(foundUser[0])
                res.status(200).send({token:token}); 
            }
            else {
                res.status(401).send(new ErrorMessage(401, 'Invalid Username or Password'));
            }
        }).catch((e) => {
            console.log(e);
        }); 
    }
    else{
        res.status(401).send(new ErrorMessage(404, 'User not Found')); 
    }
});

userRouter.get("/", (req, res, next) => {
    let currentUser = JWTAuth.VerifyToken(req.headers);
    if (currentUser instanceof User) 
    {
        res.status(200).send(usersArray); 
    } 
    else 
        res.status(401).send(new ErrorMessage(401, currentUser));
});

userRouter.post("/", (req, res, next) => {
    let currentUser = User.ToUser(req.body); 
    console.log(currentUser);
    if(currentUser instanceof User)
    {
        if(usersArray.filter(u=>u.userId == (<User>currentUser).userId).length === 0)
        {
            if(User.ValidateEmail(currentUser.emailAddress))
            {
                currentUser.setPassword(req.body.password); 
                usersArray[usersArray.length] = currentUser; 
                console.log(currentUser);
                res.status(201).send(currentUser); 
            }
            else 
                res.status(406).send(new ErrorMessage(406, 'Invalid Email Address')); 
        }
        else 
            res.status(409).send(new ErrorMessage(409, 'Duplicate User Id')); 
    }
    else 
        res.status(406).send(new ErrorMessage(401, 'Malformed User Data Recieved')); 

});

userRouter.patch("/:userId", (req, res, next)=>{
    let currentUser = JWTAuth.VerifyToken(req.headers); 
    if (currentUser instanceof User) {
        let foundUser = usersArray.filter(u=>u.userId== req.params.userId); 
        if(foundUser.length>0) {
            if(req.body.emailAddress && !User.ValidateEmail(req.body.emailAddress)) {
                res.status(406).send(new ErrorMessage(406, 'Invalid Email Address'));
            }
            else {
                if(req.body.firstName)
                    foundUser[0].firstName = req.body.firstName; 
                if(req.body.lastName)
                    foundUser[0].lastName = req.body.lastName;
                if(req.body.emailAddress)
                    foundUser[0].emailAddress = req.body.emailAddress;
                if(req.body.password)
                    foundUser[0].password = req.body.password;

            res.status(200).send(foundUser[0]);         
            }
        }
        else 
            res.status(404).send(new ErrorMessage(404, 'User not Found'));
    }
    else 
        res.status(404).send(new ErrorMessage(404, 'User not Found'));
});

userRouter.delete("/:userId", (req, res, next) => {
    let currentUser = JWTAuth.VerifyToken(req.headers); 
    if(currentUser instanceof User) {
        let foundUser = usersArray.filter(u=>u.userId == req.params.userId);
        if(foundUser.length>0) {
            usersArray.splice(usersArray.findIndex(u=>u.userId===req.params.userId),1);
            res.status(204).send('');
        }
        else {
            res.status(404).send(new ErrorMessage(404, 'User not Found'));
        }

    }
    else 
        res.status(401).send(new ErrorMessage(401, currentUser)); 
});


export {userRouter};